import UIKit

for i in 1 ... 200 {
    if i % 3 == 0 && i % 5 == 0 && i % 7 == 0 {
        print("Fizz-Buzz-Bang")
    } else if i % 3 == 0 && i % 5 == 0 {
        print("Fizz-Buzz")
    } else if i % 3 == 0 {
        print("Fizz")
    } else if i % 5 == 0 {
        print("Buzz")
    } else if i % 7 == 0 {
        print("Bang")
    } else {
    print(i)
    }




}
